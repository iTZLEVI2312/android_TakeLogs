# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
script="$0"
properties() { '
bootlogs.disabled=Bootlog Service Disabled By Flash
do.devicecheck=0
do.modules=0
do.cleanup=1
do.cleanuponabort=0
supported.versions=8 - 11
supported.patchlevels=
'; } # end properties

## AnyKernel file attributes
# set permissions/ownership for included ramdisk files
#example ramdisk set_perm_recursive
#set_perm_recursive 0 0 755 644 $ramdisk/*;
#set_perm_recursive 0 0 750 750 $ramdisk/init* $ramdisk/sbin;
chmod -R 750 $home/fries/*;
chown -R root:root $home/fries*;
mount -o remount,rw /;
mount -o remount,rw /vendor;
mount -o remount,rw /system;
mount -o remount,rw /sbin;
mount -o remount,rw /data;
mount -o remount,rw /storage;
mount -o remount,rw /sdcard;

rm -r /sdcard/BootLogs


if [ -e /vendor/etc/init/hw/init.target.rc ]; then
	target=/vendor/etc/init/hw/init.target.rc;
cp /vendor/etc/init/hw/init.target.rc~  /vendor/etc/init/hw/init.target.rc
#Adding Permission
chmod 644 /vendor/etc/init/hw/init.target.rc
#Removing Previous File
rm -rf /vendor/etc/init/hw/init.target.rc~
fi

## end install
