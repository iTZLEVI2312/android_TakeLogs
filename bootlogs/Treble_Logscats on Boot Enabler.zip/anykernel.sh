# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
script="$0"
properties() { '
bootlogs.enabling=Bootlog Service Enabling By Flash
do.devicecheck=0
do.modules=0
do.cleanup=1
do.cleanuponabort=0
supported.versions=8 - 11
supported.patchlevels=
'; } # end properties

## AnyKernel file attributes
# set permissions/ownership for included ramdisk files
#example ramdisk set_perm_recursive
#set_perm_recursive 0 0 755 644 $ramdisk/*;
#set_perm_recursive 0 0 750 750 $ramdisk/init* $ramdisk/sbin;
chmod -R 750 $home/fries/*;
chown -R root:root $home/fries*;
mount -o remount,rw /;
mount -o remount,rw /vendor;
mount -o remount,rw /system;
mount -o remount,rw /sbin;
mount -o remount,rw /data;
mount -o remount,rw /storage;
mount -o remount,rw /sdcard;

#Make Folder First For Logging Logs
mkdir -p /sdcard/BootLogs

if [ -e /vendor/etc/init/hw/init.target.rc ]; then
	target=/vendor/etc/init/hw/init.target.rc;
	cp /vendor/etc/init/hw/init.target.rc  /vendor/etc/init/hw/init.target.rc~

sed -i '$a ###################################' /vendor/etc/init/hw/init.target.rc
sed -i '$a # Logcats' /vendor/etc/init/hw/init.target.rc
sed -i '/# Logcats/a service logger /system/bin/logcat -b all -D -f /data/media/0/BootLogs/boot_log.txt' /vendor/etc/init/hw/init.target.rc
sed -i '/service logger/a class main' /vendor/etc/init/hw/init.target.rc 
sed -i '/class main/a user root' /vendor/etc/init/hw/init.target.rc
sed -i '/user root/a group root system' /vendor/etc/init/hw/init.target.rc
sed -i '/group root system/a disabled' /vendor/etc/init/hw/init.target.rc
sed -i '/disabled/a oneshot' /vendor/etc/init/hw/init.target.rc
sed -i '$a ###################################' /vendor/etc/init/hw/init.target.rc
sed -i '$a # Crash' /vendor/etc/init/hw/init.target.rc
sed -i '/# Crash/a service boot_lc_crash /system/bin/logcat -b crash -D -f /data/media/0/BootLogs/boot_lc_crash.txt' /vendor/etc/init/hw/init.target.rc
sed -i '/service boot_lc_crash/a class main' /vendor/etc/init/hw/init.target.rc 
sed -i '$a user root' /vendor/etc/init/hw/init.target.rc
sed -i '$a group root system' /vendor/etc/init/hw/init.target.rc
sed -i '$a disabled' /vendor/etc/init/hw/init.target.rc
sed -i '$a oneshot' /vendor/etc/init/hw/init.target.rc
sed -i '$a ###################################' /vendor/etc/init/hw/init.target.rc
sed -i '$a # Kernel' /vendor/etc/init/hw/init.target.rc
sed -i '/# Kernel/a service boot_lc_kernel /system/bin/logcat -b kernel -D -f /data/media/0/BootLogs/boot_lc_kernel.txt' /vendor/etc/init/hw/init.target.rc
sed -i '/service boot_lc_kernel/a class main' /vendor/etc/init/hw/init.target.rc 
sed -i '$a user root' /vendor/etc/init/hw/init.target.rc
sed -i '$a group root system' /vendor/etc/init/hw/init.target.rc
sed -i '$a disabled' /vendor/etc/init/hw/init.target.rc
sed -i '$a oneshot' /vendor/etc/init/hw/init.target.rc
sed -i '$a ##################################' /vendor/etc/init/hw/init.target.rc
sed -i '$a on post-fs-data' /vendor/etc/init/hw/init.target.rc
sed -i '/on post-fs-data/a # Clear existing logs and start the service' /vendor/etc/init/hw/init.target.rc
sed -i '/# Clear existing log/a rm\ /data/media/0/BootLogs/boot_log.txt' /vendor/etc/init/hw/init.target.rc
sed -i '$a rm\ /data/media/0/BootLogs/boot_lc_crash.txt' /vendor/etc/init/hw/init.target.rc
sed -i '$a rm\ /data/media/0/BootLogs/boot_lc_kernel.txt' /vendor/etc/init/hw/init.target.rc
sed -i '$a start logger' /vendor/etc/init/hw/init.target.rc
sed -i '$a start boot_lc_crash' /vendor/etc/init/hw/init.target.rc
sed -i '$a start boot_lc_kernel' /vendor/etc/init/hw/init.target.rc
sed -i '$a ##################################' /vendor/etc/init/hw/init.target.rc
sed -i '$a on property:sys.boot_completed=1' /vendor/etc/init/hw/init.target.rc
sed -i '/on property:sys.boot_completed=1/a # Stop the logging service' /vendor/etc/init/hw/init.target.rc
sed -i '$a stop logger' /vendor/etc/init/hw/init.target.rc
sed -i '$a stop boot_lc_crash' /vendor/etc/init/hw/init.target.rc
sed -i '$a stop boot_lc_kernel' /vendor/etc/init/hw/init.target.rc
sed -i '$a ##################################' /vendor/etc/init/hw/init.target.rc

chmod 644 /vendor/etc/init/hw/init.target.rc

fi;

## end install
